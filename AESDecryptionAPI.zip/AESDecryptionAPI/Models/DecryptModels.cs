namespace AESDecryptionAPI.Models
{
    public sealed class DecryptRequest
    {
        public string? CipherText { get; set; }
    }

    public sealed class DecryptResponse
    {
        public string PlainText { get; set; } = string.Empty;
    }

    public sealed class CyberArkSettings
    {
        public string? Url { get; set; }
        public int MaxRetries { get; set; } = 3;
        public int DelayInMs { get; set; } = 1000;
    }
} 