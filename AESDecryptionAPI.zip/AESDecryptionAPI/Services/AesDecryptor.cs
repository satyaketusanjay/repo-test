using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace AESDecryptionAPI.Services
{
    public static class AesDecryptor
    {
        public static string Decrypt(string base64CipherText, byte[] key)
        {
            if (string.IsNullOrWhiteSpace(base64CipherText))
            {
                return base64CipherText;
            }

            byte[] iv = new byte[16];
            byte[] cipherBytes = Convert.FromBase64String(base64CipherText);

            using (var aes = Aes.Create())
            {
                aes.Key = key;
                aes.IV = iv;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;

                using var decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
                using var memoryStream = new MemoryStream(cipherBytes);
                using var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
                using var streamReader = new StreamReader(cryptoStream, Encoding.UTF8);
                return streamReader.ReadToEnd();
            }
        }
    }
} 