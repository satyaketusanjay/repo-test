using System;
using System.Net.Http;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using AESDecryptionAPI.Models;

namespace AESDecryptionAPI.Services
{
    public interface IKeyManager
    {
        Task<byte[]> GetKeyAsync(CancellationToken cancellationToken);
    }

    public sealed class KeyManager : IKeyManager
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IOptions<CyberArkSettings> _settings;
        private readonly ILogger<KeyManager> _logger;

        private volatile byte[]? _cachedKey;
        private readonly SemaphoreSlim _initSemaphore = new SemaphoreSlim(1, 1);

        public KeyManager(IHttpClientFactory httpClientFactory, IOptions<CyberArkSettings> settings, ILogger<KeyManager> logger)
        {
            _httpClientFactory = httpClientFactory;
            _settings = settings;
            _logger = logger;
        }

        public async Task<byte[]> GetKeyAsync(CancellationToken cancellationToken)
        {
            if (_cachedKey != null)
            {
                return _cachedKey;
            }

            await _initSemaphore.WaitAsync(cancellationToken);
            try
            {
                if (_cachedKey != null)
                {
                    return _cachedKey;
                }

                var cfg = _settings.Value;
                if (string.IsNullOrWhiteSpace(cfg.Url))
                {
                    throw new InvalidOperationException("CyberArk:Url is not configured");
                }

                int maxRetries = Math.Max(1, cfg.MaxRetries);
                int delay = Math.Max(0, cfg.DelayInMs);

                Exception? lastError = null;
                for (int attempt = 1; attempt <= maxRetries; attempt++)
                {
                    try
                    {
                        var client = _httpClientFactory.CreateClient();
                        using var response = await client.GetAsync(cfg.Url, cancellationToken);
                        response.EnsureSuccessStatusCode();
                        var json = await response.Content.ReadAsStringAsync(cancellationToken);

                        using var doc = JsonDocument.Parse(json);
                        if (!doc.RootElement.TryGetProperty("Content", out var contentProp) || contentProp.ValueKind != JsonValueKind.String)
                        {
                            throw new InvalidOperationException("JSON 'Content' property is missing or invalid");
                        }

                        string base64 = contentProp.GetString() ?? string.Empty;
                        if (string.IsNullOrWhiteSpace(base64))
                        {
                            throw new InvalidOperationException("JSON 'Content' is empty");
                        }

                        byte[] keyBytes = Convert.FromBase64String(base64);
                        if (keyBytes.Length != 16 && keyBytes.Length != 24 && keyBytes.Length != 32)
                        {
                            throw new ArgumentException("Invalid Key Size: Encryption key should be 128/192/256 bits");
                        }

                        _cachedKey = keyBytes;
                        _logger.LogInformation("Key retrieved from CyberArk on attempt {Attempt}", attempt);
                        return _cachedKey;
                    }
                    catch (Exception ex) when (attempt < maxRetries)
                    {
                        lastError = ex;
                        _logger.LogWarning(ex, "Attempt {Attempt} failed to retrieve key; retrying in {Delay}ms", attempt, delay);
                        if (delay > 0)
                        {
                            await Task.Delay(delay, cancellationToken);
                        }
                    }
                }

                throw new InvalidOperationException("Key initialization failed completely!", lastError);
            }
            finally
            {
                _initSemaphore.Release();
            }
        }
    }
} 