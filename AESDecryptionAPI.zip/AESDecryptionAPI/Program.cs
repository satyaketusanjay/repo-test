using System.Security.Cryptography;
using System.Text;
using AESDecryptionAPI.Services;
using AESDecryptionAPI.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Bind settings
builder.Services.Configure<CyberArkSettings>(builder.Configuration.GetSection("CyberArk"));

// HttpClient factory
builder.Services.AddHttpClient();

// Key manager as singleton
builder.Services.AddSingleton<IKeyManager, KeyManager>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapPost("/decrypt", async (DecryptRequest request, IKeyManager keyManager, ILoggerFactory loggerFactory, CancellationToken cancellationToken) =>
{
    if (request == null || string.IsNullOrWhiteSpace(request.CipherText))
    {
        return Results.BadRequest(new { error = "cipherText is required" });
    }

    try
    {
        byte[] key = await keyManager.GetKeyAsync(cancellationToken);
        string plainText = AesDecryptor.Decrypt(request.CipherText, key);
        return Results.Ok(new DecryptResponse { PlainText = plainText });
    }
    catch (CryptographicException)
    {
        return Results.BadRequest(new { error = "Invalid ciphertext or key" });
    }
    catch (OperationCanceledException)
    {
        return Results.StatusCode(499); // Client Closed Request (non-standard)
    }
    catch (Exception ex)
    {
        var logger = loggerFactory.CreateLogger("Decrypt");
        logger.LogError(ex, "Unexpected error during decryption");
        return Results.Problem(title: "Decryption failed", statusCode: 500);
    }
})
.WithName("Decrypt")
.WithOpenApi();

app.Run();
